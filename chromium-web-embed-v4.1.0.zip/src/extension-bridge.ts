import { BRIDGE_CHANNEL, isBridgeCommand } from "./protocol.js";

export function installExtensionBridge(): void {
  const globalAny = globalThis as Record<string, unknown>;
  if (globalAny.__realBrowserWebBridgeInstalled) return;
  globalAny.__realBrowserWebBridgeInstalled = true;

  window.addEventListener("message", (event: MessageEvent) => {
    if (event.source !== window) return;
    if (!isBridgeCommand(event.data)) return;

    const command = event.data;
    chrome.runtime.sendMessage(
      {
        scope: "real-browser-bridge",
        command,
      },
      (response) => {
        const runtimeError = chrome.runtime.lastError;
        window.postMessage(
          runtimeError
            ? {
                channel: command.channel ?? BRIDGE_CHANNEL,
                id: command.id,
                ok: false,
                error: runtimeError.message,
              }
            : response,
          window.location.origin || "*"
        );
      }
    );
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.scope === "real-browser-event" && message.event) {
      window.postMessage(
        {
          channel: BRIDGE_CHANNEL,
          event: message.event,
        },
        window.location.origin || "*"
      );
    }
  });
}
